defmodule Core.Semantic.EventFrames do
  @moduledoc """
  Small symbolic event-frame extraction from already-normalized Core state.

  This sits after intent and LIFG sense selection: it does not decide the response,
  it preserves structured meaning for later memory, action selection, and UI traces.
  """

  alias Core.Pipeline.Trace

  @medication_terms ~w(quetiapine seroquel medication medicine meds dose)

  @spec attach(map(), keyword()) :: map()
  def attach(si, _opts \\ [])

  def attach(%{} = si, _opts) do
    case health_support_frame(si) do
      nil ->
        si

      frame ->
        si
        |> Map.put(:symbolic_frame, frame)
        |> Trace.append(:event_frame,
          decision: :attached,
          reason: :health_support_semantics,
          scores: %{confidence: Map.get(frame, :confidence, 0.0)},
          meta: frame
        )
    end
  end

  def attach(other, _opts), do: other

  defp health_support_frame(si) do
    text = normalized_text(si)

    with true <- health_support_turn?(si, text),
         medication when is_binary(medication) <- medication_mention(si, text) do
      forgot? = Regex.match?(~r/\b(forgot|forget|missed|skip(?:ped)?)\b/u, text)
      sleep_inability? = sleep_inability?(text)

      if forgot? or sleep_inability? do
        %{
          type: :health_support_event,
          subject: :user,
          event: if(forgot?, do: :forgot_medication, else: :health_disclosure),
          medication: medication,
          consequence: if(sleep_inability?, do: :sleep_inability, else: nil),
          temporal_context: if(Regex.match?(~r/\bnow\b/u, text), do: :now, else: nil),
          domain: :health_support,
          polarity: if(sleep_inability?, do: :negative, else: nil),
          confidence: frame_confidence(forgot?, sleep_inability?)
        }
        |> drop_nil_values()
      end
    else
      _ -> nil
    end
  end

  defp health_support_turn?(si, text) do
    Map.get(si, :intent) == :health_support or
      Map.get(si, :topic_domain) in [:health_sleep_medication, :health_medication] or
      Regex.match?(~r/\b(quetiapine|seroquel|medication|medicine|meds|dose)\b/u, text)
  end

  defp medication_mention(si, text) do
    choices =
      si
      |> Map.get(:lifg_choices, [])
      |> List.wrap()

    from_choices =
      Enum.find_value(choices, fn
        %{pos: "entity", lemma: lemma, id: id} ->
          if medication_entity_id?(id), do: normalize(lemma), else: nil

        %{pos: :entity, lemma: lemma, id: id} ->
          if medication_entity_id?(id), do: normalize(lemma), else: nil

        %{} = choice ->
          id = Map.get(choice, :id) || Map.get(choice, "id")
          lemma = Map.get(choice, :lemma) || Map.get(choice, "lemma")
          if medication_entity_id?(id), do: normalize(lemma || phrase_from_id(id)), else: nil

        _ ->
          nil
      end)

    from_choices || medication_from_text(text)
  end

  defp medication_entity_id?(id) when is_binary(id), do: String.contains?(id, "|medication")
  defp medication_entity_id?(_), do: false

  defp medication_from_text(text) do
    Enum.find(@medication_terms, &Regex.match?(~r/\b#{Regex.escape(&1)}\b/u, text))
  end

  defp sleep_inability?(text) do
    Regex.match?(~r/\b(can'?t|cannot|can\s+not|unable\s+to|not\s+able\s+to)\s+sleep\b/u, text) or
      Regex.match?(~r/\b(haven'?t|have\s+not)\s+been\s+able\s+to\s+sleep\b/u, text) or
      Regex.match?(~r/\btrouble\s+sleeping\b/u, text)
  end

  defp frame_confidence(true, true), do: 0.90
  defp frame_confidence(true, false), do: 0.82
  defp frame_confidence(false, true), do: 0.76

  defp normalized_text(si) do
    [
      get_in(si, [:fuzzy_text, :text]),
      Map.get(si, :primary_text),
      Map.get(si, :keyword),
      Map.get(si, :sentence),
      Map.get(si, "sentence")
    ]
    |> Enum.find_value("", fn
      text when is_binary(text) and text != "" -> normalize(text)
      _ -> nil
    end)
  end

  defp normalize(text) when is_binary(text) do
    text
    |> String.downcase()
    |> String.replace(~r/[^\p{L}\p{N}'\s]/u, " ")
    |> String.replace(~r/\s+/u, " ")
    |> String.trim()
  end

  defp normalize(_), do: ""

  defp phrase_from_id(id) when is_binary(id) do
    id
    |> String.split("|", parts: 2)
    |> List.first()
    |> normalize()
  end

  defp phrase_from_id(_), do: ""

  defp drop_nil_values(map), do: Map.reject(map, fn {_key, value} -> is_nil(value) end)
end
