# P-201 — Tokenizer defaults (test): words-only, no char-grams
import Config
config :brain, :ml_enabled, false

config :db, Db.Repo,
  pool: Ecto.Adapters.SQL.Sandbox,
  ownership_timeout: 60_000

# -------------------------------
# Database (umbrella app: :db)
# -------------------------------
config :db, ecto_repos: [Db]

config :db, Db,
  username: "postgres",
  password: "postgres",
  hostname: "localhost",
  database: "symbrella_db_test",
  pool: Ecto.Adapters.SQL.Sandbox,
  pool_size: 10,
  show_sensitive_data_on_connection_error: true

# -------------------------------
# Web (no server during tests)
# -------------------------------
config :symbrella_web, SymbrellaWeb.Endpoint,
  http: [ip: {127, 0, 0, 1}, port: 4002],
  secret_key_base: "14hiEvqKbnYtZ+2qDPg34F/YD7XKAZIhRV2/+Tu0m00q/a2ba7en3+E9Dr010Ze7",
  server: false

# -------------------------------
# Mailer (test adapter) - FIXED
# -------------------------------
config :symbrella, Symbrella.Mailer, adapter: Swoosh.Adapters.Test
config :swoosh, :api_client, false

# -------------------------------
# LLM runner (disabled unless a test opts in)
# -------------------------------
config :llm, Llm,
  auto_start_on_boot?: false,
  allow_lazy_start?: false,
  auto_restart_on_crash?: false,
  heartbeat_ms: 0

# -------------------------------
# Logger / ExUnit
# -------------------------------
config :logger, level: :warning
config :ex_unit, capture_log: true

# -------------------------------
# Phoenix runtime knobs for tests
# -------------------------------
config :phoenix, :plug_init_mode, :runtime

config :phoenix_live_view,
  enable_expensive_runtime_checks: true

# -------------------------------
# Core tokenizer defaults (tests)
# -------------------------------
config :core, :tokenizer_defaults,
  mode: :words,
  emit_chargrams: false

# -------------------------------
# Brain Configuration (FIXED)
# -------------------------------
config :brain,
  # Episodic mode during tests
  episodes_mode: :on,

  # LIFG test stability (relaxed thresholds)
  lifg_min_score: 0.5,
  lifg_min_margin: 0.08,
  lifg_min_p_top1: 0.60,
  lifg_stage1_scores_mode: :all,
  lifg_stage1_weights: %{
    lex_fit: 0.40,
    rel_prior: 0.30,
    activation: 0.20,
    intent_bias: 0.10
  },

  # pMTG defaults
  pmtg_mode: :boost,
  pmtg_margin_threshold: 0.15,
  pmtg_window_keep: 50,

  # Hippocampus configuration
  hippo_meta_dup_count: false,
  allow_test_ids: true

# FIXED: Proper thalamus configuration
config :brain, Brain.Thalamus,
  ofc_weight: 0.42,
  acc_alpha: 0.37

# Telemetry version fix
config :brain, :telemetry_version, 2

# Math precision settings
config :brain, :math_precision, 1.0e-2

# Curiosity configuration
config :brain, :curiosity,
  enabled: true,
  test_mode: true
